
# check Python version
import sys
if sys.hexversion < 0x3050000:
    print("Error: Python 3.5 or greater needed")
    print("Please install Python 3.5 or later")
    print("Program STOP!!!")
    exit()

# check required modules
module_error=''
try:
    import pandas
    print("pandas module ok")
except:
    module_error = module_error + "pandas "
    
try:
    import Bio # for Biopython module
    print("Biopython module ok")
except:
    module_error = module_error + "Biopython "
    
try:
    import xlrd # for openpyxl
    print("xlrd module ok")
except:
    module_error = module_error + "xlrd "

try:
    import openpyxl
    print("openpyxl module ok")
except:
    module_error = module_error + "openpyxl "

try:
    import cython # for pysam
    print("cython module ok")
except:
    module_error = module_error + "cython "
    
try:
    import pysam
    print("pysam module ok")
except:
    module_error = module_error + "pysam "


if module_error != '':
    print("modules "+module_error+" not installed")
    print("Program STOP!!!")
    exit()

print("continue")



